package com.example.quizmaster;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class Quiz extends AppCompatActivity {

    public int i = 1;
    public int score = 0;

    @Override
    public void onBackPressed(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        TextView question = findViewById(R.id.Question);
        RadioGroup options = findViewById(R.id.Options);
        RadioButton option1 = findViewById(R.id.Option1);
        RadioButton option2 = findViewById(R.id.Option2);
        RadioButton option3 = findViewById(R.id.Option3);
        RadioButton option4 = findViewById(R.id.Option4);
        Button reset = findViewById(R.id.Reset);
        Button next = findViewById(R.id.Next);
        Button submit = findViewById(R.id.Submit);

        String[][] QuestionAnswer = {
                //{"Question 1", "Option 1", "Option 2", "Option 3", "Option 4", "Answer"},
                {"Height of Mount Everest ?", "1000 m", "8909 m", "8848 m", "8.7 Km", "8848 m"},
                {"Creator of BitCoin ?", "Satoshi Nakamoto", "Eddy Murphy", "Ryan Gosling", "Alex Pandian", "Satoshi Nakamoto"},
                {"Color of Sky ?", "Red", "Blue", "Green", "Purple", "Blue"},
                {"Full form of HP ?", "Hero Petrol", "High Price", "Hector Pack", "Havllet Packart", "Havllet Packart"},
                {"India's Capital ?", "Delhi", "Mumbai", "Chennai", "Banglore", "Delhi"},
        };

        question.setText(QuestionAnswer[0][0]);
        option1.setText(QuestionAnswer[0][1]);
        option2.setText(QuestionAnswer[0][2]);
        option3.setText(QuestionAnswer[0][3]);
        option4.setText(QuestionAnswer[0][4]);
        next.setEnabled(false);

        options.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if(i < 5)
                    next.setEnabled(true);
                else{
                    submit.setEnabled(true);
                }
            }
        });


        reset.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                options.clearCheck();
                if(i < 5)
                    next.setEnabled(false);
                else
                    submit.setEnabled(false);
            }
        });

        next.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                int selectId = options.getCheckedRadioButtonId();
                RadioButton radioButton = (RadioButton) findViewById(selectId);
                if(radioButton.getText() == QuestionAnswer[i - 1][5]){
                    score += 10;
                }

                options.clearCheck();

                if(i == 4){
                    next.setVisibility(View.INVISIBLE);
                    submit.setVisibility(View.VISIBLE);
                    submit.setEnabled(false);
                }

                question.setText(QuestionAnswer[i][0]);
                option1.setText(QuestionAnswer[i][1]);
                option2.setText(QuestionAnswer[i][2]);
                option3.setText(QuestionAnswer[i][3]);
                option4.setText(QuestionAnswer[i][4]);
                i += 1;

                next.setEnabled(false);
            }
        });

        submit.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int selectId = options.getCheckedRadioButtonId();
                RadioButton radioButton = (RadioButton) findViewById(selectId);
                if(radioButton.getText() == QuestionAnswer[4][5]){
                    score += 10;
                }

                Intent Score = new Intent(getApplicationContext(), Score.class);
                Score.putExtra("Score", Integer.toString(score));
                Score.putExtra("Correct", Integer.toString(score/10));
                Score.putExtra("Incorrect", Integer.toString(5 - score/10));
                startActivity(Score);
            }
        });
    }
}

// 5=10
//4=19