package com.example.quizmaster;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Score extends AppCompatActivity {

    @Override
    public void onBackPressed(){

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        Button quit = findViewById(R.id.Quit);

        TextView CorrectNumber = findViewById(R.id.CorrectNumber);
        TextView IncorrectNumber = findViewById(R.id.IncorrectNumber);
        TextView TotalScore = findViewById(R.id.TotalScore);

        Intent Score = getIntent();
        String FinalScore = Score.getStringExtra("Score");
        String TotalCorrect = Score.getStringExtra("Correct");
        String TotalIncorrect = Score.getStringExtra("Incorrect");

        CorrectNumber.setText(TotalCorrect);
        IncorrectNumber.setText(TotalIncorrect);
        TotalScore.setText(FinalScore);

        quit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                finishAffinity();
            }
        });
    }
}