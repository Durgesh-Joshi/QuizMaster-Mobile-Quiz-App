package com.example.quizmaster;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Rules extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rules);

        Button back = findViewById(R.id.back);
        TextView rules = findViewById(R.id.rulesOfQuiz);

        rules.setText("1. Do not Copy \n\n" +
                      "2. Do not Use Internet \n\n" +
                      "3. Do not move forward without selecting Option \n\n" +
                      "4. You cannot visit Previous Question \n\n" +
                      "5. Do not Press Back Button on Quiz Window \n\n" +
                      "6. Use Quit Button on Score Window to Quit App \n\n"
                    );

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent MainActivity = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(MainActivity);
            }
        });
    }
}